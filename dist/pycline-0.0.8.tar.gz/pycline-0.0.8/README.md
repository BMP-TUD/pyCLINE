# PyCLINE - python package for CLINE

The `pyCLINE` package is the python package based on the CLINE (**C**omputational **L**earning and **I**nference of **N**ullcline **E**quations) introduced in the manuscript XXX. 